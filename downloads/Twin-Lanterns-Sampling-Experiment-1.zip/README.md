# Twin Lanterns — Sampling Experiment 1

Diagnostic comparison. Not a Kriegsspinne release or a confirmed fix
for Phantom Brigade. No voxel lighting, bounce or temporal history.

## Install and compare

1. Extract this archive outside the game's shader search paths. Copy only its
   `reshade-shaders` folder into the game. Keep your installed `ReShade.fxh`.
2. Keep the depth buffer selection, persistence/capture settings, resolution
   and working depth inversion unchanged. If your working preset contains
   `RESHADE_DEPTH_*` definitions, copy those same definitions into each test
   preset's `PreprocessorDefinitions=` line before switching presets. These
   supplied presets do not establish your game's depth configuration.
3. Select **Lunar Flower - Twin Lanterns: Local Sampling Experiment**. Disable
   the other Twin Lanterns techniques and other effects for the comparison.
4. At the same camera position, compare the four supplied presets:

| Preset | Sampling | Normals |
|---|---|---|
| 01 Baseline | Existing first-hit sampling | Existing |
| 02 Smooth Sampling | Multiple weighted samples | Existing |
| 03 Softer Normals | Existing first-hit sampling | Softer |
| 04 Both | Multiple weighted samples | Softer |

Start with **01 versus 02**. Compare **Applied Light** and **Final Image**.
Then compare 01 versus 03. Check whether the center line changes, whether light
crosses object boundaries, and whether fine geometry loses definition. Use
Final Image for timing; diagnostic views can execute different work.

All four use four cardinal directions, 16 samples per provider, 24-pixel reach,
the same light/reconstruction settings and forced-off bounce. The baseline is
the existing first-gather algorithm with a separate effect/texture identity.
Installing this folder does not replace Kriegsspinne's shader folder.

Smooth sampling is substantially more expensive in a dense supported scene.
One synthetic direction used 156 depth reads and 30 color reads versus 17 and
2 for first-hit sampling. Those counts exclude the receiver guide and later
passes; they are not GPU timing or FPS predictions. Stop the comparison if
its frame cost is unsuitable. Unchecking the whole technique stops its passes.

## What changed

The smooth mode integrates admitted donors over the scheduled ray samples,
using two cubic transitions around our existing coarse depth interval. Each
transition extends one eighth of that interval's width beyond its edge. It
preserves ray reach, march jitter, strict invalid-depth rejection, self-hit
rejection, distance loss and final light/channel ceilings. It removes first-hit
termination and refinement. Multiple visible donors may carry more light across
boundaries: this is screen-space reconstruction, not complete scene visibility.

The normal experiment multiplies our existing normal Z regularization by eight.
It retains our derivative selection, validity and depth-edge policy. Eight is
an experimental factor, not a calibrated Unity setting. It can also change
surface agreement during reconstruction, not only transport.

The retained graph has five full-resolution RGBA16F fields and six passes.
Bounce is forcibly disabled, including when settings are edited. In smooth
mode, provider coverage diagnostics indicate supported sampling, not a selected
first hit. Bounce-specific views are inactive.

## Source and limits

All bundled shader files derive from Lunar Flower's own Provider Performance
source and an independently written experiment. GoldenWeave Redux was studied
as a behavioral reference; its shader code and assets are not included.
The original Lunar Flower license is retained.

The archive contains no chat logs, screenshots, personal presets, credentials,
repository metadata, external framework headers or compiled test binaries.
See `SOURCE_MANIFEST.json`, `CHANGES.patch` and `VALIDATION.json` for the exact
source changes and test results. The ReShade technique keeps its original
"Local Sampling Experiment" label for compatibility with the supplied presets.

ReShade 6.7.3 FX parsing and SM5 HLSL generation passed for all four variants.
CPU fixtures check sampling continuity, baseline equivalence, invalid depth,
source preservation and output ceilings. They do not establish FXC/DXC or driver
compilation, GPU timing, visual acceptance or resolution of the reported seam.
